#!bin/bash

export MS_ID="cicd-test-user"
export VERSION="v1.0.0"