package neowise.user.service.security.authentication;

public class AuthenticationResource {

    public static final String ENDPOINT = "/authentication";
    public static final String BASE_RESOURCE = "";

}
