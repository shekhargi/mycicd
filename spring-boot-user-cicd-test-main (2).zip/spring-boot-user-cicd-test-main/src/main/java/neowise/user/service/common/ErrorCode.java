package neowise.user.service.common;

public enum ErrorCode {
	SERVICE_FAILURE, //
	AUTHENTICATION_ERROR, //
	AUTHORIZATION_ERROR, //
}
